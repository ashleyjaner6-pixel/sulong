class DisqusCommentsPlugin {
	constructor (API, name, config) {
		this.API = API;
		this.name = name;
		this.config = config;
	}

	addInsertions () {
		this.API.addInsertion('customCommentsCode', this.addEntryScripts, 1, this);
	}

	escapeAttribute (value) {
		return String(value ?? '')
			.replace(/&/g, '&amp;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	escapeText (value) {
		return String(value ?? '')
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	serializeForScript (value) {
		return JSON.stringify(String(value ?? ''))
			.replace(/</g, '\\u003C')
			.replace(/\u2028/g, '\\u2028')
			.replace(/\u2029/g, '\\u2029');
	}

	getPageData (rendererInstance, context) {
		let url = '';
		let id = '';

		if (rendererInstance.globalContext && rendererInstance.globalContext.website) {
			url = rendererInstance.globalContext.website.pageUrl || '';
		}

		if (context && context.post && context.post.id) {
			id = context.post.id;
		} else if (context && context.page && context.page.id) {
			id = context.page.id;
		} else {
			id = url;
		}

		return {
			id: String(id || ''),
			url: String(url || '')
		};
	}

	getShortname () {
		const shortname = String(this.config.shortname || '')
			.trim()
			.replace(/^https?:\/\//i, '')
			.split('/')[0]
			.replace(/\.disqus\.com$/i, '');

		return /^[A-Za-z0-9_-]+$/.test(shortname) ? shortname : '';
	}

	getCookieGroup () {
		const group = String(this.config.cookieBannerGroup || '').trim();

		return /^[A-Za-z0-9_-]+$/.test(group) ? group : '';
	}

	getLanguage () {
		const language = String(this.config.language || '').trim();

		if (/^en[-_]GB$/i.test(language)) {
			return '';
		}

		return language;
	}

	getLoaderScript (shortname, page, cookieGroup) {
		const language = this.getLanguage();
		const lazyload = Boolean(this.config.lazyload);
		const languageLine = language
			? `this.language = ${this.serializeForScript(language)};`
			: '';
		const loader = `
			(function () {
				var target = document.getElementById('disqus_thread');
				var loadDisqus = function () {
					if (document.querySelector('script[data-disqus-comments-loader]')) {
						return;
					}

					var script = document.createElement('script');
					script.src = 'https://${shortname}.disqus.com/embed.js';
					script.setAttribute('data-disqus-comments-loader', '');
					script.setAttribute('data-timestamp', String(+new Date()));
					(document.head || document.body).appendChild(script);
				};

				window.disqus_config = function () {
					this.page.url = ${this.serializeForScript(page.url)};
					this.page.identifier = ${this.serializeForScript(page.id)};
					${languageLine}
				};

				if (${lazyload} && target && 'IntersectionObserver' in window) {
					var observer = new IntersectionObserver(function (entries) {
						for (var i = 0; i < entries.length; i++) {
							if (entries[i].isIntersecting) {
								observer.disconnect();
								loadDisqus();
								break;
							}
						}
					}, { rootMargin: '200px 0px' });

					observer.observe(target);
				} else {
					loadDisqus();
				}
			}());
		`;
		const type = cookieGroup ? ` type="gdpr-blocker/${cookieGroup}"` : '';

		return `<script${type}>${loader}</script>`;
	}

	getConsentMarkup (cookieGroup) {
		if (!cookieGroup) {
			return { notice: '', script: '' };
		}

		const notice = `
			<div
				data-gdpr-group="gdpr-blocker/${cookieGroup}"
				data-disqus-consent-notice="${cookieGroup}"
				style="background: #f0f0f0; border: 1px solid #ccc; border-radius: 5px; color: #666; display: block; margin-top: 10px; padding: 10px; text-align: center; width: 100%;">
				${this.escapeText(this.config.cookieBannerNoConsentText)}
			</div>
		`;
		const script = `
			<script>
				document.body.addEventListener('publii-cookie-banner-unblock-${cookieGroup}', function () {
					var notices = document.querySelectorAll('[data-disqus-consent-notice="${cookieGroup}"]');

					for (var i = 0; i < notices.length; i++) {
						notices[i].style.display = 'none';
					}
				}, false);
			</script>
		`;

		return { notice, script };
	}

	getPreviewNotice (message) {
		return `<div role="status" data-comments-preview-notice="disqus" style="background: #f0f0f0; border: 1px solid #ccc; border-radius: 5px; color: #666; display: block; padding: 10px; text-align: center; width: 100%;">${this.escapeText(message)}</div>`;
	}

	addEntryScripts (rendererInstance, context) {
		const shortname = this.getShortname();
		const page = this.getPageData(rendererInstance, context);
		const previewMode = Boolean(rendererInstance.previewMode);
		const cookieGroup = this.config.cookieBannerIntegration ? this.getCookieGroup() : '';
		const hasInvalidCookieConfiguration = this.config.cookieBannerIntegration && !cookieGroup;
		const shouldLoad = !previewMode && shortname && !hasInvalidCookieConfiguration;
		const headingLevel = /^[2-6]$/.test(String(this.config.headingLevel)) ? this.config.headingLevel : '2';
		const cssHeaderClass = this.config.cssHeaderClass ? ` class="${this.escapeAttribute(this.config.cssHeaderClass)}"` : '';
		const cssWrapperClass = this.config.cssWrapperClass ? ` class="${this.escapeAttribute(this.config.cssWrapperClass)}"` : '';
		const cssInnerWrapperClass = this.config.cssInnerWrapperClass ? ` class="${this.escapeAttribute(this.config.cssInnerWrapperClass)}"` : '';
		const consent = !previewMode && shortname && !hasInvalidCookieConfiguration
			? this.getConsentMarkup(cookieGroup)
			: { notice: '', script: '' };
		let heading = '';
		let statusNotice = '';
		let comments = '';
		let loader = '';

		if (this.config.textHeader) {
			heading = `<h${headingLevel}${cssHeaderClass}>${this.escapeText(this.config.textHeader)}</h${headingLevel}>`;
		}

		if (previewMode && !shortname) {
			statusNotice = this.getPreviewNotice('Disqus comments cannot be previewed because the Disqus shortname is missing. Add it in the plugin settings.');
		} else if (previewMode && hasInvalidCookieConfiguration) {
			statusNotice = this.getPreviewNotice('Disqus comments cannot be previewed because the Cookie Group ID is missing or invalid. Check the plugin settings.');
		} else if (previewMode) {
			statusNotice = this.getPreviewNotice('Disqus comments are not loaded in Publii preview. Publish your site to a test URL to verify the integration.');
		} else if (!shortname) {
			statusNotice = '<!-- Disqus Comments: A valid shortname is required. -->';
		} else if (hasInvalidCookieConfiguration) {
			statusNotice = '<!-- Disqus Comments: Cookie Banner integration requires a valid Cookie Group ID. -->';
		}

		if (!previewMode && shortname && !hasInvalidCookieConfiguration) {
			comments = '<div id="disqus_thread"></div>';
		}

		if (shouldLoad) {
			loader = this.getLoaderScript(shortname, page, cookieGroup);
		}

		return `
			<div${cssWrapperClass}>
				<div${cssInnerWrapperClass}>
					${heading}
					${statusNotice}
					${comments}
					<noscript>${this.escapeText(this.config.textFallback)}</noscript>
					${consent.notice}
				</div>
			</div>
			${loader}
			${consent.script}
		`;
	}
}

module.exports = DisqusCommentsPlugin;
